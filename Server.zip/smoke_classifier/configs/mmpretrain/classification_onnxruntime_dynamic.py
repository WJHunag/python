_base_ = ['./classification_dynamic.py', '../_base_/backends/onnxruntime.py']
