_base_ = ['../_base_/onnx_config.py']

codebase_config = dict(type='mmpretrain', task='Classification')
