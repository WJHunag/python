# Copyright (c) OpenMMLab. All rights reserved.
from .bbox_nms import efficient_nms

__all__ = ['efficient_nms']
