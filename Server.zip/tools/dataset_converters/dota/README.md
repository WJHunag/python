# Preparing DOTA Dataset

Please refer to [Dataset preparation and description](../../../docs/en/recommended_topics/dataset_preparation.md)
