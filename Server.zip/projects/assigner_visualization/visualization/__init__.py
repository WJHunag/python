# Copyright (c) OpenMMLab. All rights reserved.
from .assigner_visualizer import YOLOAssignerVisualizer

__all__ = ['YOLOAssignerVisualizer']
